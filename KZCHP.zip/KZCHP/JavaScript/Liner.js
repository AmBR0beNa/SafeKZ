const mySlider = new Splide('#mySlider',{
    perPage:2,
    gap:'30px'
})

mySlider.mount()